const openBtn=document.getElementById("openBtn");
const start=document.getElementById("start");
const birthday=document.getElementById("birthday");
const confetti=document.getElementById("confetti");
const wishBtn=document.getElementById("wishBtn");
const wishText=document.getElementById("wishText");

function sparkleField(){
  const field=document.getElementById("sparkles");
  for(let i=0;i<28;i++){
    const s=document.createElement("span");
    s.className="spark"; s.textContent=["✦","✧","⋆"][i%3];
    s.style.left=Math.random()*100+"vw";
    s.style.top=Math.random()*100+"vh";
    s.style.animationDelay=(Math.random()*2.5)+"s";
    s.style.fontSize=(10+Math.random()*12)+"px";
    field.appendChild(s);
  }
}
function makeConfetti(){
  const symbols=["✦","◆","●","★","♡"];
  for(let i=0;i<65;i++){
    const p=document.createElement("span");
    p.className="confetti-piece";
    p.textContent=symbols[i%symbols.length];
    p.style.left=Math.random()*100+"vw";
    p.style.setProperty("--x",(Math.random()*240-120)+"px");
    p.style.animationDelay=(Math.random()*.9)+"s";
    p.style.fontSize=(8+Math.random()*10)+"px";
    confetti.appendChild(p);
    setTimeout(()=>p.remove(),4000);
  }
}
function cuteMusic(){
  // Melodía original generada con Web Audio; no necesita archivos externos.
  const AC=window.AudioContext||window.webkitAudioContext;
  if(!AC)return;
  const ctx=new AC();
  const notes=[523.25,659.25,783.99,659.25,587.33,698.46,880,698.46,523.25,659.25,783.99,1046.5];
  let t=ctx.currentTime+.05;
  notes.forEach((freq,i)=>{
    const o=ctx.createOscillator(), g=ctx.createGain();
    o.type="sine"; o.frequency.value=freq;
    g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(.045,t+.03);
    g.gain.exponentialRampToValueAtTime(.001,t+.38);
    o.connect(g).connect(ctx.destination); o.start(t); o.stop(t+.4);
    t+=.34;
  });
}
openBtn.addEventListener("click",()=>{
  openBtn.disabled=true;
  cuteMusic();
  start.classList.remove("active");
  birthday.classList.add("active");
  makeConfetti();
});
wishBtn.addEventListener("click",()=>{
  wishText.textContent="✨ Que se cumpla ese deseo, José. ✨";
  makeConfetti();
});
sparkleField();

TARJETA DE CUMPLEAÑOS PARA JOSÉ 💙

Archivos:
- index.html
- style.css
- script.js

Para verla:
1. Abre index.html en un navegador.
2. Toca el regalo.
3. La melodía se genera dentro de la página (no requiere un archivo de audio).

Para convertirla en un link público puedes subir estos archivos a un servicio de páginas estáticas como GitHub Pages.
